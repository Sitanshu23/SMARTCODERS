from django.urls import path
from . import views

urlpatterns=[
    path("",views.index),
    path("home/",views.index),
    path("about/",views.about),
    path("contact/",views.contact),
    path("gallery/",views.gallery),
    path("team/",views.team),
    path("services/",views.services),
    path("login/",views.login),
    path("register/",views.register),
    path("logout/",views.logout),
]